<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // spajamo se na net
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ss";
        
        
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        
     if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    }
    
  else {
        echo("<h1>spojen sam!</h1>");    
    }
        
        
    
    
    $sql = "insert into wp_term_relationships (object_id, term_taxonomy_id) values (1, 1)";
    
    if(mysqli_query($conn, $sql))
    {
         echo "New record created successfully";
    }
    
    
    else
    {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    
    
    
    
        
        
        
        ?>
    </body>
</html>
